const API = location.port === '5173' ? 'http://localhost:3000/api' : '/api';

const products = [
  { id: 1, name: 'JOSIPBARABA Classic', price: 24.99, image: '/img1/slika1.jpg', desc: 'Premium pamučna majica s clean logom.' },
  { id: 2, name: 'JOSIPBARABA Neon', price: 27.99, image: '/img1/slika2.jpg', desc: 'Gaming stil, jak print i moderan fit.' },
  { id: 3, name: 'JOSIPBARABA Limited', price: 29.99, image: '/img1/slika6.jpg', desc: 'Limitirani drop za prave fanove.' },
  { id: 4, name: 'JOSIPBARABA Dark', price: 26.99, image: '/img1/slika7.jpg', desc: 'Tamni streetwear look za svaki dan.' },
];

const logoGallery = [
  '/img1/slika1.jpg', '/img1/slika2.jpg', '/img1/slika6.jpg', '/img1/slika7.jpg',
];

const state = {
  user: JSON.parse(localStorage.getItem('jb_user') || 'null'),
  token: localStorage.getItem('jb_token') || '',
  cart: JSON.parse(localStorage.getItem('jb_cart') || '[]'),
  selectedImage: products[0].image,
};

const money = (n) => `${n.toFixed(2)} €`;
const saveCart = () => localStorage.setItem('jb_cart', JSON.stringify(state.cart));
const saveAuth = () => {
  if (state.user && state.token) {
    localStorage.setItem('jb_user', JSON.stringify(state.user));
    localStorage.setItem('jb_token', state.token);
  } else {
    localStorage.removeItem('jb_user');
    localStorage.removeItem('jb_token');
  }
};

function render() {
  document.querySelector('#app').innerHTML = `
    <header class="hero">
      <nav class="nav">
        <a class="brand" href="#top">JOSIPBARABA</a>
        <div class="nav-links">
          <a href="#products">Majice</a>
          <a href="#gallery">Galerija</a>
          <a href="#login">Prijava</a>
        </div>
        <button id="cartBtn" class="cart-btn">Košarica <span id="cartCount">${cartQty()}</span></button>
      </nav>
      <section id="top" class="hero-content">
        <p class="tag">Gaming merch shop</p>
        <h1>Majice s JOSIPBARABA dizajnom</h1>
        <p>Odaberi majicu, veličinu i količinu. Ulogiraj se, naruči i sve se sprema na backend.</p>
        <div class="hero-actions">
          <a href="#products" class="cta">Pogledaj majice</a>
          <a href="#login" class="ghost-btn">${state.user ? `Bok, ${state.user.name}` : 'Prijavi se'}</a>
        </div>
      </section>
    </header>

    <main>
      <section id="products" class="section">
        <div class="section-head">
          <p class="tag">Shop</p>
          <h2>Majice</h2>
        </div>
        <div class="grid">${products.map(productCard).join('')}</div>
      </section>

      <section id="gallery" class="section split">
        <div>
          <p class="tag">Galerija</p>
          <h2>Logo i slike</h2>
          <p class="muted">Sve slike za proizvode i galeriju dolaze iz foldera <strong>img1</strong>.</p>
          <div class="thumbs">${logoGallery.map(galleryThumb).join('')}</div>
        </div>
        <div class="preview-card"><img id="previewImage" src="${state.selectedImage}" alt="Galerija preview"></div>
      </section>

      <section id="login" class="section auth-section">
        <div class="auth-card">
          <p class="tag">Korisnik</p>
          <h2>${state.user ? 'Moj profil' : 'Prijava / registracija'}</h2>
          ${state.user ? profileHtml() : authHtml()}
        </div>
      </section>
    </main>

    <div id="overlay" class="overlay"></div>
    <aside id="cartDrawer" class="cart-drawer">${cartHtml()}</aside>
  `;

  bindEvents();
}

function productCard(p) {
  return `
    <article class="card">
      <img src="${p.image}" alt="${p.name}">
      <div class="card-body">
        <h3>${p.name}</h3>
        <p class="muted">${p.desc}</p>
        <p class="price">${money(p.price)}</p>
        <div class="options">
          <select id="size-${p.id}" aria-label="Veličina">
            <option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option>
          </select>
          <input id="qty-${p.id}" aria-label="Količina" type="number" min="1" value="1">
        </div>
        <button class="add-btn" data-add="${p.id}">Dodaj u košaricu</button>
      </div>
    </article>`;
}

function galleryThumb(src) {
  return `<button class="thumb ${state.selectedImage === src ? 'active' : ''}" data-gallery="${src}"><img src="${src}" alt="Galerija slika"></button>`;
}

function authHtml() {
  return `
    <div class="tabs"><button class="tab active" data-tab="loginForm">Prijava</button><button class="tab" data-tab="registerForm">Registracija</button></div>
    <form id="loginForm" class="auth-form">
      <input name="email" type="email" placeholder="Email" required>
      <input name="password" type="password" placeholder="Lozinka" required>
      <button class="checkout" type="submit">Prijavi se</button>
    </form>
    <form id="registerForm" class="auth-form hidden">
      <input name="name" placeholder="Ime" required>
      <input name="email" type="email" placeholder="Email" required>
      <input name="password" type="password" placeholder="Lozinka" minlength="4" required>
      <button class="checkout" type="submit">Registriraj se</button>
    </form>
    <p id="authMsg" class="order-message"></p>`;
}

function profileHtml() {
  return `
    <div class="profile-box">
      <p><strong>Ime:</strong> ${state.user.name}</p>
      <p><strong>Email:</strong> ${state.user.email}</p>
      <button id="logoutBtn" class="ghost-btn">Odjava</button><button id="deleteProfileBtn" class="remove-profile">Izbriši profil</button>
    </div>
    <h3>Moje narudžbe</h3>
    <div id="ordersBox" class="orders-box">Učitavanje...</div>`;
}

function cartQty() { return state.cart.reduce((sum, item) => sum + item.qty, 0); }
function cartTotal() { return state.cart.reduce((sum, item) => sum + item.qty * item.price, 0); }

function cartHtml() {
  return `
    <div class="drawer-header"><h2>Košarica</h2><button id="closeCart" class="close">×</button></div>
    <div class="cart-items">
      ${state.cart.length ? state.cart.map((item, i) => `
        <div class="cart-line">
          <div><strong>${item.name}</strong><small>${item.size} · ${item.qty} kom · ${money(item.price)}</small></div>
          <button class="remove" data-remove="${i}">Makni</button>
        </div>`).join('') : '<p class="muted">Košarica je prazna.</p>'}
    </div>
    <div class="cart-footer">
      <div class="total-row"><strong>Ukupno</strong><span>${money(cartTotal())}</span></div>
      <button id="checkoutBtn" class="checkout">Završi narudžbu</button>
      <p id="orderMsg" class="order-message"></p>
    </div>`;
}

function bindEvents() {
  document.querySelector('#cartBtn').onclick = openCart;
  document.querySelector('#closeCart').onclick = closeCart;
  document.querySelector('#overlay').onclick = closeCart;

  document.querySelectorAll('[data-add]').forEach(btn => btn.onclick = () => addToCart(Number(btn.dataset.add)));
  document.querySelectorAll('[data-remove]').forEach(btn => btn.onclick = () => removeItem(Number(btn.dataset.remove)));
  document.querySelectorAll('[data-gallery]').forEach(btn => btn.onclick = () => { state.selectedImage = btn.dataset.gallery; render(); location.hash = '#gallery'; });

  document.querySelector('#checkoutBtn').onclick = checkout;
  document.querySelector('#logoutBtn')?.addEventListener('click', () => { state.user = null; state.token = ''; saveAuth(); render(); });

  document.querySelectorAll('[data-tab]').forEach(btn => btn.onclick = () => switchTab(btn.dataset.tab));
  document.querySelector('#loginForm')?.addEventListener('submit', (e) => authSubmit(e, 'login'));
  document.querySelector('#registerForm')?.addEventListener('submit', (e) => authSubmit(e, 'register'));

  if (state.user) loadOrders();
  const delBtn=document.querySelector('#deleteProfileBtn'); if(delBtn) delBtn.onclick=deleteProfile;
}

function switchTab(id) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === id));
  document.querySelectorAll('.auth-form').forEach(f => f.classList.toggle('hidden', f.id !== id));
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  const size = document.querySelector(`#size-${id}`).value;
  const qty = Math.max(1, Number(document.querySelector(`#qty-${id}`).value || 1));
  const existing = state.cart.find(i => i.id === id && i.size === size);
  if (existing) existing.qty += qty;
  else state.cart.push({ ...product, size, qty });
  saveCart();
  render();
updateNavOnScroll();
  openCart();
}

function removeItem(index) {
  state.cart.splice(index, 1);
  saveCart();
  render();
  openCart();
}

function openCart() {
  document.querySelector('#cartDrawer').classList.add('open');
  document.querySelector('#overlay').classList.add('show');
}
function closeCart() {
  document.querySelector('#cartDrawer').classList.remove('open');
  document.querySelector('#overlay').classList.remove('show');
}

async function authSubmit(e, mode) {
  e.preventDefault();
  const msg = document.querySelector('#authMsg');
  const body = Object.fromEntries(new FormData(e.currentTarget).entries());
  const res = await fetch(`${API}/${mode}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data = await res.json();
  if (!res.ok) { msg.textContent = data.error || 'Greška.'; return; }
  state.user = data.user; state.token = data.token; saveAuth(); render();
}

async function checkout() {
  const msg = document.querySelector('#orderMsg');
  if (!state.user) { msg.textContent = 'Prvo se prijavi ili registriraj.'; return; }
  if (!state.cart.length) { msg.textContent = 'Košarica je prazna.'; return; }
  const res = await fetch(`${API}/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${state.token}` },
    body: JSON.stringify({ items: state.cart, total: cartTotal() }),
  });
  const data = await res.json();
  if (!res.ok) { msg.textContent = data.error || 'Narudžba nije spremljena.'; return; }
  state.cart = []; saveCart(); render(); openCart();
  const emailText = data.order.emailStatus === 'sent' ? ' Email je poslan vlasniku i tvrtki.' : ' Email nije poslan jer SMTP nije podešen, ali je spremljen u email-outbox.json.';
  document.querySelector('#orderMsg').textContent = `Narudžba #${data.order.id} je zaprimljena!${emailText}`;
}

async function loadOrders() {
  const box = document.querySelector('#ordersBox');
  const res = await fetch(`${API}/orders`, { headers: { Authorization: `Bearer ${state.token}` } });
  const data = await res.json();
  if (!res.ok || !data.orders.length) { box.textContent = 'Još nema narudžbi.'; return; }
  box.innerHTML = data.orders.map(o => `<div class="order"><strong>#${o.id}</strong> · ${money(o.total)}<small>${new Date(o.createdAt).toLocaleString('hr-HR')} · email: ${o.emailStatus || 'nije navedeno'}</small></div>`).join('');
}

render();
updateNavOnScroll();


async function deleteProfile() {
  if (!confirm('Jesi siguran da želiš izbrisati profil?')) return;
  const res = await fetch(`${API}/profile`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${state.token}` }
  });
  const data = await res.json();
  if (!res.ok) return alert(data.error || 'Greška.');
  state.user = null;
  state.token = '';
  state.cart = [];
  saveAuth();
  saveCart();
  alert('Profil je izbrisan.');
  render();
}


function updateNavOnScroll() {
  const nav = document.querySelector('.nav');
  if (!nav) return;
  nav.classList.toggle('scrolled', window.scrollY > 35);
}

window.addEventListener('scroll', updateNavOnScroll);
