# JOSIPBARABA Web Shop

Full stack webshop za majice.

## Pokretanje

```bash
npm install
npm start
```

Otvori: http://localhost:3000

## Što je dodano

- galerija slika iz `img` i `img1`
- proizvodi/majice s veličinom i količinom
- košarica
- registracija i prijava korisnika
- backend API u `server.js`
- spremanje korisnika i narudžbi u `database.json`

## Dev frontend

```bash
npm run dev
```

Backend pokreni posebno s `npm start`.


## Slanje narudžbi e-mailom

Narudžba se automatski šalje na:

- `josipbaraba2005@gmail.com`
- `informatika.merz@gmail.com`

Za stvarno slanje e-mailova kopiraj `.env.example` u `.env` i upiši SMTP podatke. Primjer za Gmail: koristi Gmail App Password, ne običnu lozinku.

```bash
cp .env.example .env
npm install
npm start
```

Ako SMTP nije podešen, narudžba se svejedno spremi u `database.json`, a pripremljeni e-mail spremi se u `email-outbox.json`.


## Ispravak registracije
Ako je prije pisalo `Server greška` kod registracije, ovaj update više ne koristi `crypto.randomUUID()`, pa radi i na starijim Node verzijama. Ipak preporuka je Node.js 18+.
