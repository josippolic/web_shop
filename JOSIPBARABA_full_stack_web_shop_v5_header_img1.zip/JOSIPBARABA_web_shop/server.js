import http from 'node:http';
import { promises as fs, readFileSync } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function loadEnvFile() {
  try {
    const envPath = path.join(__dirname, '.env');
    const content = readFileSync(envPath, 'utf8');
    content.split(/\r?\n/).forEach(line => {
      const clean = line.trim();
      if (!clean || clean.startsWith('#') || !clean.includes('=')) return;
      const [key, ...rest] = clean.split('=');
      if (!process.env[key]) process.env[key] = rest.join('=').trim().replace(/^['"]|['"]$/g, '');
    });
  } catch {}
}
loadEnvFile();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'database.json');
const sessions = new Map();
function makeToken() { return crypto.randomBytes(32).toString('hex'); }

const OWNER_EMAIL = process.env.OWNER_EMAIL || 'josipbaraba2005@gmail.com';
const COMPANY_EMAIL = process.env.COMPANY_EMAIL || 'informatika.merz@gmail.com';
const OUTBOX_FILE = path.join(__dirname, 'email-outbox.json');

async function appendOutbox(entry) {
  let outbox = [];
  try { outbox = JSON.parse(await fs.readFile(OUTBOX_FILE, 'utf8')); }
  catch { outbox = []; }
  outbox.push(entry);
  await fs.writeFile(OUTBOX_FILE, JSON.stringify(outbox, null, 2));
}

function orderEmailText(order, user) {
  const lines = order.items.map((item, index) =>
    `${index + 1}. ${item.name} | veličina: ${item.size} | količina: ${item.qty} | cijena: ${Number(item.price).toFixed(2)} €`
  ).join('\n');
  return `Nova narudžba #${order.id}

Kupac: ${user.name}
Email kupca: ${user.email}
Datum: ${new Date(order.createdAt).toLocaleString('hr-HR')}
Ukupno: ${Number(order.total).toFixed(2)} €

Artikli:
${lines}

Ova poruka je automatski poslana iz JOSIPBARABA webshopa.`;
}

function orderEmailHtml(order, user) {
  const rows = order.items.map(item => `
    <tr>
      <td style="padding:8px;border:1px solid #ddd;">${item.name}</td>
      <td style="padding:8px;border:1px solid #ddd;">${item.size}</td>
      <td style="padding:8px;border:1px solid #ddd;">${item.qty}</td>
      <td style="padding:8px;border:1px solid #ddd;">${Number(item.price).toFixed(2)} €</td>
    </tr>`).join('');
  return `
    <h2>Nova narudžba #${order.id}</h2>
    <p><strong>Kupac:</strong> ${user.name}<br><strong>Email kupca:</strong> ${user.email}<br><strong>Datum:</strong> ${new Date(order.createdAt).toLocaleString('hr-HR')}</p>
    <table style="border-collapse:collapse;width:100%;max-width:760px;">
      <thead><tr><th style="padding:8px;border:1px solid #ddd;text-align:left;">Majica</th><th style="padding:8px;border:1px solid #ddd;text-align:left;">Veličina</th><th style="padding:8px;border:1px solid #ddd;text-align:left;">Količina</th><th style="padding:8px;border:1px solid #ddd;text-align:left;">Cijena</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <h3>Ukupno: ${Number(order.total).toFixed(2)} €</h3>
    <p>Ova poruka je automatski poslana iz JOSIPBARABA webshopa.</p>`;
}

async function sendOrderEmail(order, user) {
  const recipients = [OWNER_EMAIL, COMPANY_EMAIL].filter(Boolean).join(', ');
  const subject = `Nova narudžba #${order.id} - JOSIPBARABA shop`;
  const email = { to: recipients, subject, text: orderEmailText(order, user), html: orderEmailHtml(order, user), createdAt: new Date().toISOString() };

  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    await appendOutbox({ ...email, status: 'not_sent_missing_smtp_settings' });
    return { sent: false, reason: 'SMTP nije podešen. Email je spremljen u email-outbox.json.' };
  }

  const nodemailer = await import('nodemailer');
  const transporter = nodemailer.default.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || 'false') === 'true',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  await transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.SMTP_USER,
    to: recipients,
    replyTo: user.email,
    subject,
    text: email.text,
    html: email.html
  });
  return { sent: true };
}

const mime = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml'
};

async function ensureDb() {
  try { await fs.access(DB_FILE); }
  catch { await fs.writeFile(DB_FILE, JSON.stringify({ users: [], orders: [] }, null, 2)); }
}
async function readDb() { await ensureDb(); return JSON.parse(await fs.readFile(DB_FILE, 'utf8')); }
async function writeDb(db) { await fs.writeFile(DB_FILE, JSON.stringify(db, null, 2)); }
function hash(password) { return crypto.createHash('sha256').update(password).digest('hex'); }
function send(res, status, data) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data)); }
async function body(req) { const chunks = []; for await (const c of req) chunks.push(c); return chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {}; }
function currentUser(req, db) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  const userId = sessions.get(token);
  return db.users.find(u => u.id === userId);
}

async function api(req, res) {
  const db = await readDb();
  if (req.method === 'POST' && req.url === '/api/register') {
    const data = await body(req);
    if (!data.name || !data.email || !data.password) return send(res, 400, { error: 'Popuni sva polja.' });
    if (db.users.some(u => u.email.toLowerCase() === data.email.toLowerCase())) return send(res, 409, { error: 'Email već postoji.' });
    const user = { id: Date.now(), name: data.name, email: data.email.toLowerCase(), passwordHash: hash(data.password) };
    db.users.push(user); await writeDb(db);
    const token = makeToken(); sessions.set(token, user.id);
    return send(res, 201, { token, user: { id: user.id, name: user.name, email: user.email } });
  }
  if (req.method === 'POST' && req.url === '/api/login') {
    const data = await body(req);
    const user = db.users.find(u => u.email === String(data.email || '').toLowerCase() && u.passwordHash === hash(data.password || ''));
    if (!user) return send(res, 401, { error: 'Krivi email ili lozinka.' });
    const token = makeToken(); sessions.set(token, user.id);
    return send(res, 200, { token, user: { id: user.id, name: user.name, email: user.email } });
  }

  if (req.method === 'DELETE' && req.url === '/api/profile') {
    const user = currentUser(req, db);
    if (!user) return send(res, 401, { error: 'Prijava je obavezna.' });
    db.users = db.users.filter(u => u.id !== user.id);
    db.orders = db.orders.filter(o => o.userId !== user.id);
    for (const [token, uid] of sessions.entries()) {
      if (uid === user.id) sessions.delete(token);
    }
    await writeDb(db);
    return send(res, 200, { success: true });
  }
  if (req.url === '/api/orders') {
    const user = currentUser(req, db);
    if (!user) return send(res, 401, { error: 'Prijava je obavezna.' });
    if (req.method === 'GET') return send(res, 200, { orders: db.orders.filter(o => o.userId === user.id).reverse() });
    if (req.method === 'POST') {
      const data = await body(req);
      if (!Array.isArray(data.items) || !data.items.length) return send(res, 400, { error: 'Košarica je prazna.' });
      const order = { id: Date.now(), userId: user.id, items: data.items, total: Number(data.total || 0), createdAt: new Date().toISOString(), emailStatus: 'pending' };
      let emailResult = { sent: false };
      try {
        emailResult = await sendOrderEmail(order, user);
        order.emailStatus = emailResult.sent ? 'sent' : 'saved_to_outbox';
        order.emailInfo = emailResult.reason || 'Email poslan vlasniku i tvrtki.';
      } catch (error) {
        order.emailStatus = 'failed';
        order.emailInfo = error.message;
        await appendOutbox({ orderId: order.id, status: 'failed', error: error.message, createdAt: new Date().toISOString() });
      }
      db.orders.push(order); await writeDb(db);
      return send(res, 201, { order, email: emailResult });
    }
  }
  send(res, 404, { error: 'API ruta ne postoji.' });
}

async function staticFile(req, res) {
  let urlPath = decodeURIComponent(req.url.split('?')[0]);
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.normalize(path.join(__dirname, urlPath));
  if (!filePath.startsWith(__dirname)) { res.writeHead(403); return res.end('Forbidden'); }
  try {
    const data = await fs.readFile(filePath);
    res.writeHead(200, { 'Content-Type': mime[path.extname(filePath)] || 'application/octet-stream' });
    res.end(data);
  } catch {
    const data = await fs.readFile(path.join(__dirname, 'index.html'));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(data);
  }
}

const server = http.createServer(async (req, res) => {
  try { req.url.startsWith('/api/') ? await api(req, res) : await staticFile(req, res); }
  catch (error) { console.error('SERVER ERROR:', error); send(res, 500, { error: 'Server greška.', details: error.message }); }
});

server.listen(PORT, () => console.log(`JOSIPBARABA shop radi na http://localhost:${PORT}`));
